//----------------------------------------------------------------------
/*
 Name - MyJobUITests.swift
 Description:
 1.
 Created by divya_ios on 24/08/18.
 Last updated on - 24/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------
import XCTest

class MyJobUITests: XCTestCase {
    
    var app: XCUIApplication!
    
    
    override func setUp() {
        super.setUp()
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        app = XCUIApplication()
        app.launch()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testJobView(){
        /* 1.Test the tableview exist and Segment exist .
         2.Check segment tap action
         3.Check status label and swipe action
         */
        
        //Navigate to My job screen
        let myJobsButton = self.app.tabBars.buttons["My Jobs"]
        myJobsButton.tap()
        myJobsButton.tap() //tap my job button
        
        self.app.segmentedControls.buttons["Saved"].tap()
        self.app.segmentedControls.buttons["Applied"].tap()

        let tableView = self.app.tables.element(boundBy: 0)
        tableView.swipeDown()
        tableView.swipeUp()
        
        self.app.tables.cells.element(boundBy: 0).swipeLeft() //Check swipe action

        
    }
    
}
