//----------------------------------------------------------------------
/*
 Name - HomeViewUITests.swift
 Description:
 1.Tab bar flows.
 2.Home screen tableview testing
 Created by divya_ios on 16/08/18.
 Last updated on - 16/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import XCTest

class HomeViewUITests: XCTestCase {
    
    var app: XCUIApplication!
    
    
    override func setUp() {
        super.setUp()
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        app = XCUIApplication()
        app.launch()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testTabbar(){
        /* 1.Check whether the tab bar is exist or not.
         2.Check tap action for all the tab bar items.
         */
       
        let tabBars = app.tabBars //Get instance for tab bar

        tabBars.buttons["Home"].tap()//Check tap action for all bar item
        tabBars.buttons["My Jobs"].tap()
        tabBars.buttons["Messages"].tap()
        tabBars.buttons["Profile"].tap()
    }
    
    func testHomeView(){
        /* 1.Test the tableview exist and registration of cell to that.
         2.Check scroll in tableview
         */
        let tabBars = app.tabBars //Get instance for tab bar
        tabBars.buttons["Home"].tap()//Move to home view controller
        let jobTables = app.tables.element(boundBy: 0) //Get the instant of tableview
        jobTables.swipeUp()
        jobTables.swipeDown()
        
        if(jobTables.cells.count != 0){ //If table contains data
            let firstCell = jobTables.cells.element(boundBy: 0) //Check tab action in tableview
            firstCell.buttons["ViewButton"].tap()
            firstCell.buttons["SaveHit"].tap()
            firstCell.tap() //Check didselect action of cell
        }
    }
    
    func testQuickFilterView() {
        /* 1.Check scroll in quick filter collection view and collection view exist.
         2.Check quick filter selection.
         */
        app.tabBars.buttons["Home"].tap() //Move to home view controller
        let quickFilterView = app.collectionViews.element(boundBy: 0) // Get the instant of collectionview
        let firstCell = quickFilterView.cells.element(boundBy: 0) //Get instance of cell
        let secondCell = quickFilterView.cells.element(boundBy: 1)

        //Check filter tap action
        firstCell.tap() //If 1st cell selected - Button tick showed
        quickFilterView.swipeUp()
        XCTAssertTrue(quickFilterView.buttons["btnTick"].exists == true)

        secondCell.tap() //If 2nd cell selected - Button tick showed  & 1st Cell - Button tick hidden
        quickFilterView.swipeUp()
        XCTAssertTrue(secondCell.buttons["btnTick"].exists == true)
        XCTAssertTrue(firstCell.buttons["btnTick"].exists == false)

        secondCell.tap() //If cell tapped 2 times continuesly - Button tick hidden
        XCTAssertTrue(secondCell.buttons["btnTick"].exists == false)
        
        quickFilterView.swipeLeft()
        quickFilterView.swipeRight()
        quickFilterView.swipeUp() //To check whether vertical scrolling is disabled.

        
        //Check whether all the filter datas are exist
        XCTAssertTrue(quickFilterView.staticTexts["Recommended"].exists)
        XCTAssertTrue(quickFilterView.staticTexts["Featured"].exists)
        XCTAssertTrue(quickFilterView.staticTexts["Trending"].exists)
        quickFilterView.swipeLeft() //To visible last cell
        XCTAssertTrue(quickFilterView.staticTexts["Urgent"].exists)
        quickFilterView.swipeRight()
    }
    
    func testSearchBar(){
        
        /*1.Check cancel button hidden show functionality
         2.Check all button action in search bar (Clear,Cancel,Filter)
 */

        let searchBar = app.searchFields["Search Jobs Titles or Companies"]
        searchBar.tap()
        searchBar.typeText("Company Name")
        searchBar.buttons["Clear text"].tap()//Check clear button
        searchBar.tap()
        let goButton = app.keyboards.buttons["Go"]
        goButton.tap()//If empty keyboard will not dismiss and cancel button will be in hidden state
        XCTAssertTrue(app.buttons["Cancel"].exists == false)

        searchBar.typeText("Company Name")
        goButton.tap()
        XCTAssertTrue(app.buttons["Cancel"].exists)//Cancel button

        app.buttons["Cancel"].tap()
        
        let bookmarksButton = searchBar.buttons["Bookmarks"]
        bookmarksButton.tap()

    }
    
    func testFilterScreen(){
        
        /*1.Present Filter screen
         2.Check multiple selection functionality
         3.Check reset and close button
         */
        
        app.searchFields["Search Jobs Titles or Companies"].buttons["Bookmarks"].tap()//Present filter screen
        
        let tablesQuery = app.tables//Instance for tableview

        tablesQuery.cells.element(boundBy: 0).tap()
        XCTAssertTrue(tablesQuery.cells.element(boundBy: 0).images["Tick"].exists == true)//Check selection

        tablesQuery.cells.element(boundBy: 1).tap()
        XCTAssertTrue(tablesQuery.cells.element(boundBy: 1).images["Tick"].exists == true)

        tablesQuery.cells.element(boundBy: 1).tap()
        XCTAssertTrue(tablesQuery.cells.element(boundBy: 1).images["Tick"].exists == false)//Check unselect by clicking the same index
        
        
        tablesQuery.cells.element(boundBy: 9).tap()
        XCTAssertTrue(tablesQuery.cells.element(boundBy: 9).images["Tick"].exists == true)//Check multi select

        
        app.buttons["Reset"].tap() //Tap reset button

        XCTAssertTrue(tablesQuery.cells.element(boundBy: 9).buttons["Tick"].exists == false)
        
        XCTAssertTrue(tablesQuery.cells.element(boundBy: 0).buttons["Tick"].exists == false)
        tablesQuery.element(boundBy: 0).swipeUp()
        tablesQuery.element(boundBy: 0).swipeDown()

        app.buttons["Cancel"].tap() //Tap close button
        
    }
    
    func testPerformanceOfHome() {
        self.measureMetrics([XCTPerformanceMetric.wallClockTime], automaticallyStartMeasuring: false) {
            startMeasuring()
            testHomeView() //Check performance timing of home view
            testQuickFilterView()
            stopMeasuring()
        }
    }
    
    func testPerformanceOfFilter() {
        self.measureMetrics([XCTPerformanceMetric.wallClockTime], automaticallyStartMeasuring: false) {
            startMeasuring()
            testFilterScreen() //Check performance timing of home view
            stopMeasuring()
        }
    }

    func testExample() {
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
}
