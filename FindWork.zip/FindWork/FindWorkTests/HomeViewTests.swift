//
//  HomeViewTests.swift
//  FindWorkTests
//
//  Created by divya_ios on 16/08/18.
//  Copyright © 2018 divya_ios. All rights reserved.
//

import XCTest
@testable import FindWork

class HomeViewTests: XCTestCase {
    
    var controllerUnderTest: HomeViewController!

    
    override func setUp() {
        super.setUp()
        //Initiate the view controller to test
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: HomeViewController = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        controllerUnderTest = vc
        _ = controllerUnderTest.view //To call view did load
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testTabBar(){
        
    }

    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
}


