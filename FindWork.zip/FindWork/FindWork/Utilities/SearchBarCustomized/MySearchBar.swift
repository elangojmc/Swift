//----------------------------------------------------------------------
/*
 Name - MySearchBar.swift
 Description:
 1.Changed tint color for search icon.
 2.Changed image for clear button - Bcos ios 11 will not support to change tint color
 3.Replaced bookmark icon with filter icon
 Created by divya_ios on 21/08/18.
 Last updated on - 21/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

@IBDesignable
class MySearchBar: UISearchBar {
    
    @IBInspectable var iconTintColor : UIColor = UIColor.white
    @IBInspectable var rightViewImage : UIImage = UIImage()
    @IBInspectable var placeholderColor : UIColor = UIColor.white
    @IBInspectable var textColor : UIColor = UIColor.white
    
    override func draw(_ rect: CGRect) {
        setupSearchBar()
    }
    
    func setupSearchBar(){
        //Get instance for textfield inside search bar and changed font and color
        let textFieldInsideSearchBar = self.value(forKey: "searchField") as? UITextField
        textFieldInsideSearchBar?.textColor = textColor
        textFieldInsideSearchBar?.font = UIFont(name: "SFUIText-Regular", size: 14)
        
        //Changed placeholder color for teatfield
        let textFieldInsideSearchBarLabel = textFieldInsideSearchBar!.value(forKey: "placeholderLabel") as? UILabel
        textFieldInsideSearchBarLabel?.textColor = placeholderColor
        
        //Search icon tint color changed
        let searchIcon = textFieldInsideSearchBar?.leftView as? UIImageView
        searchIcon?.image = searchIcon?.image?.withRenderingMode(.alwaysTemplate)
        searchIcon?.tintColor = iconTintColor
        
        //Clear button image is changed bcos in ios 11 tint color not support for clear button

        if let clearButton = textFieldInsideSearchBar?.value(forKey: "clearButton") as? UIButton{
        clearButton.setImage(UIImage(named: "ClearTextIcon"), for: .normal)
        }
        
        //Changed cancel button color
        UIBarButtonItem.appearance(whenContainedInInstancesOf:[UISearchBar.self]).tintColor = UIColor.white

        
        //Set filter image to bookmark
        self.setImage(rightViewImage, for: .bookmark, state: UIControlState.normal)

    }
    
    
    
}
