//----------------------------------------------------------------------
/*
 Name - AppUserDefault.swift
 Description:
 1.
 Created by divya_ios on 27/08/18.
 Last updated on - 27/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import Foundation
//dummy datas
var bearerToken = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImY4OWEyYTI1YzdkOWFkMjYyMDUzNjY4MjY0Y2FmOWNkMWQyOWQzZDE4NGZkYzlmMzI2YWI2MzAyYzNkYjMyNjU2NjU1ZjJkZGZmODdkMWM2In0.eyJhdWQiOiIyIiwianRpIjoiZjg5YTJhMjVjN2Q5YWQyNjIwNTM2NjgyNjRjYWY5Y2QxZDI5ZDNkMTg0ZmRjOWYzMjZhYjYzMDJjM2RiMzI2NTY2NTVmMmRkZmY4N2QxYzYiLCJpYXQiOjE1MzU1MjQ1MjQsIm5iZiI6MTUzNTUyNDUyNCwiZXhwIjoxNTY3MDYwNTI0LCJzdWIiOiIzNiIsInNjb3BlcyI6WyIqIl19.CNgbOBoxEZ5pG-mZETkeqKQomUZVws8XDeUp4OajL5wVSo3G2FkL0W2mKQwdZdJGHETGX3XA_GTIWQIBKeBOxEenS7LBrVzCM4ilxVHUHZMAjXpvSVeRzZt3lUIhKpI44ow4fYKBHu5n2QXlrEqq3CtwgRwG1HxCRJxkr7JIBCLjUuiVtBjAjypQFBB_aZHM_S5fws4fT9S_uiUEDTWJM-w7f4qAb2piYNzo_IfbRXivedy062_um4JgPlemXbm9YkUA5P3cQvDJqPN39Uxy2NSYGIA71q2pIgpmTcTyFVTBa74sws0BmOhitZ3pdwonVcAbdkT-SmYZDQ8eiCeU7DIhD_ViPB3lx8yib0mEMqhDSWPS7htxZqJip4RR_HoDCzhev_sjgvZGg0VON06gOMvi8r1S0eAcXj59HWvFUwo1JfwNk1JlIw6juNyqFsR5yB7vVzP4uyitl-hhKhO2CNS3X0ybhcRDdAMc1o4-z_nk4wf4uC7UNtpfBQ93pc6_WgbxmdkM_cR3Z73D8lgJYhvqZrgJZ6pF08qbwg5JCgAwctj_5XpRp1RptgkMiQFt3aliQaPwsuzEIiKkqjrtAbCHxmWQFdBwnfX_fzIHeNCDJIqodCixc9E9sURHmvWIhE_6X1XoJdXNJ3-wzBzHKO8JdaNAvtUHM3WNuSNH8OM"

struct AppUserDefault {
    
    
    private static var userDefault = UserDefaults.standard
     private init() {}
    static var accessToken:String? { //To store Access token
        get {
            return userDefault.value(forKey: "auth_Token") as? String ?? ""
        }
        set {
            userDefault.set(bearerToken, forKey: "auth_Token")
            userDefault.synchronize()
         }
    }
}


