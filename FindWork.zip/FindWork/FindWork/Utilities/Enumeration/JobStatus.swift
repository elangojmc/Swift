//----------------------------------------------------------------------
/*
 Name - JobStatus.swift
 Description:
 1.Enum class for handling job status.
 Created by divya_ios on 8/23/18.
 Last updated on - 8/23/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import Foundation
import UIKit

enum AppliedJobStatus : String{ //Job status - In My job (Applied)
    case New = "New"
    case Notsuitable = "NotSuitable"
    case ShortListed = "ShortListed"
    case Interview = "Interview"
    case Hired  = "Hired"
    
    var color : UIColor{
        
        switch self {
        case .New:
            return UIColor.yellow
        case .Notsuitable:
            return UIColor.red
        case .ShortListed:
            return UIColor.lightGreen
        case .Interview:
            return UIColor.violet
        case .Hired:
            return UIColor.skyBlue
        }
    }
    
    var swipeTitle : String{ //Select title for swipe action
        switch self {
        case .New:
            return "Withdraw"
        default:
            return "Remove"
        }
    }
    
    var swipeTitleColor : UIColor{ //Select image for swipe action
        switch self {
        case .New:
            return UIColor.grayText
        default:
            return UIColor.white
        }
    }
    
    var swipebackgroundColor : UIColor{ //Select image for swipe action
        switch self {
        case .New:
            return UIColor.swipeGray
        default:
            return UIColor.red
        }
    }
    
    var swipeImage : UIImage{ //Select image for swipe action
        switch self {
        case .New:
            return #imageLiteral(resourceName: "CloseGray")
        default:
            return #imageLiteral(resourceName: "Delete")
        }
    }
}
