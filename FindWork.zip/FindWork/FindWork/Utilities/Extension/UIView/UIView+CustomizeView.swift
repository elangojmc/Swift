//----------------------------------------------------------------------
/*
 Name - UIView+CustomizeView.swift
 Description:
 1.Customize the layer of UIView - Include all uielement
 Created by divya_ios on 14/08/18.
 Last updated on - 14/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

extension UIView {
    
    @IBInspectable var cornerRadius: CGFloat { //Can rounded the corner in storyboard
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }
    
    @IBInspectable var borderWidth: CGFloat { //Can change the width of the layer in storyboard
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
            layer.masksToBounds = newValue > 0
        }
    }
    
    @IBInspectable var bordercolor: UIColor { //Can change the color of the layer in storyboard
        get {
            return self.bordercolor
        }
        set {
            layer.borderColor = newValue.cgColor
        }
    }
    
    
}

extension CALayer {
    //Can apply shadow to the layer - Include all UIElement
    func applySketchShadow(color: UIColor = .black,alpha: Float = 0.7,x: CGFloat = 0,y: CGFloat = 5,blur: CGFloat = 12,spread: CGFloat = 6){ //All params are optional, if the param is not passed, it will take the default value
        shadowColor = color.cgColor
        masksToBounds = false
        shadowOpacity = alpha
        shadowOffset = CGSize.zero
        shadowRadius = blur
    }
    
    func setGradientEffect(colorTop: UIColor, colorBottom: UIColor){
        //Give gradient effect to the view
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame.size = self.frame.size
        gradientLayer.colors = [colorTop.cgColor, //Color from top tp bottom(Increase step by step)
                                colorBottom.withAlphaComponent(0.3).cgColor,
                                colorBottom.withAlphaComponent(0.5).cgColor,
                                colorBottom.withAlphaComponent(0.7).cgColor]
        gradientLayer.locations = [0.0, 0.2,0.5, 1] //Location for setting that colors array to the view
        self.addSublayer(gradientLayer) //Add as sublayer
    }
}

