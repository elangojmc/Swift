//----------------------------------------------------------------------
/*
 Name - UIColor+Primary.swift
 Description:
 1.Created extension for all primary color which is used in our app.
 Created by divya_ios on 14/08/18.
 Last updated on - 14/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

extension UIColor{
    
    static var seaBlue = UIColor(red: 82/255, green: 179/255, blue: 208/255, alpha: 1) //Main app theme color
    static var grayShadow = UIColor(red: 217/255, green: 226/255, blue: 233/255, alpha: 1)//This color is used for giving shadow effect to the view
    static var grayShadowOnCell = UIColor(red: 249/255, green: 249/255, blue: 249/255, alpha: 1)//This color is used for giving light background color to cell
    static var grayText = UIColor(red: 155/255, green: 155/255, blue: 155/255, alpha: 1)//This color is used for text
    static var grayishBrownText = UIColor(red: 67/255, green: 67/255, blue: 67/255, alpha: 1)//Selected Text
    static var swipeGray = UIColor(red: 228/255, green: 228/255, blue: 228/255, alpha: 1)//Selected Text


    static var yellow = UIColor.init(red: 245/255, green: 166/255, blue: 35/255, alpha: 1.0) // Thiz color is used for appliedJob Status "New"
    static var red = UIColor.init(red: 180/255, green: 15/255, blue: 71/255, alpha: 1.0)  // This color is used for AppliedJob Status "Not Suitable"
    static var lightGreen =  UIColor.init(red: 111/255, green: 182/255, blue: 33/255, alpha: 1.0) // This color is used for AppliedJob Status "ShortListed"
    static var violet = UIColor.init(red: 189/255, green: 16/255, blue: 224/255, alpha: 1.0) // This color is used for AppliedJob Status "ShortListed"
    static var skyBlue = UIColor.init(red: 25/255, green: 217/255, blue: 180/255, alpha: 1.0) // This color is used for AppliedJob Status "Hired"
}
