//----------------------------------------------------------------------
/*
 Name - HelperClass.swift
 Description:
 1.
 Created by divya_ios on 17/08/18.
 Last updated on - 17/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

//Singleton class.
class Constant {
    static let screenSize: CGRect = UIScreen.main.bounds //Screen Size
}
