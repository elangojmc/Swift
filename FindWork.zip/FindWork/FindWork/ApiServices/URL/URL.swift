//----------------------------------------------------------------------
/*
 Name - Url
 Description:
 1.List of Api urls
 Created by divya_ios on 2/17/17.
 Last updated on - 17/1/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------
import Foundation

class Url {
    
    static var BASE_URL = "https://api.staging.findwork.io/v1/" //Staging Url
    
    //Authenticate Url
    static var API_LOGIN =   "auth/register"
    static var API_REGISTER = "auth/login"
    
    //Home screen - Job list
    static var API_JOBS = "jobs"
    
}
