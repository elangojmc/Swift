//
//  NetworkManager.swift
//  FindWork
//
//  Created by divya_ios on 25/08/18.
//  Copyright © 2018 divya_ios. All rights reserved.
//

import UIKit
import Alamofire
import Reachability

enum Result<T:Decodable> {
 
    case success(data:T) //Success response
    case failure(message:String)//APi call error
    case error(message:String) //Network error
}

enum ApiStatus {
    case NoData
    case NetworkError
    case Success
}

class NetworkManager {
    
    class func apiRequest<T:Decodable>(urlString:String,Method:HTTPMethod,parameter:Parameters,isLoadingNeeded:Bool = true,completion:@escaping (Result<T>)->()) {

        isNetworkAvailable { (statusBool,message) in
            if statusBool{
               
                AppUserDefault.accessToken = bearerToken
                if(isLoadingNeeded == true){
                    
                }
                
                let headers = [
                    "Authorization": "\(AppUserDefault.accessToken!)" //Access token
                ]

                let url = URL(string:"\(Url.BASE_URL)\(urlString)")!
                print("\(url) \n \(headers) \n \(parameter)")

                switch Method{ //If post put delete method
                case .post,
                     .put,
                     .delete:

                    Alamofire.request(url, method:Method, parameters: parameter, encoding: JSONEncoding.default, headers: headers).responseJSON { (response) in
                        let model = self.responseDecode(response: response.data!, modelType: T.self) //Get response of respective model class
                        completion(model)
                        
                    }
                case.get: //If get method
                    Alamofire.request(url, method:Method, parameters: parameter, headers: headers).responseJSON { (response) in
                        print(response.result.value)
                        let model = self.responseDecode(response: response.data!, modelType: T.self) //Get response of respective model class
                        completion(model)
                    
                    }
                default:
                    break
                }
            } else{
                completion(Result<T>.error(message: ""))//Return network failure message
            }
        }
    }
    
    
    class func responseDecode<T:Decodable>(response:Data,modelType:T.Type)-> Result<T>{
        //Decode the response to respective model class
        do {
            let model = try JSONDecoder().decode(modelType.self, from: response)
            return Result<T>.success(data: model)
        } catch let error {
            print(error)
            return Result<T>.error(message: error.localizedDescription) //If failure
        }
    }
    
    class func isNetworkAvailable(completionHandler:@escaping (_ success:Bool, _ message:String) -> ())
    {
        let reachability = Reachability() //Check network availability
        reachability?.whenReachable = { reachability in
            DispatchQueue.main.async ()
                {
                    if reachability.connection == .wifi{
                        completionHandler(true,"wifi")
                    } else {
                        completionHandler(true,"mobilen/w")
                    }
            }
        }
        reachability?.whenUnreachable = { reachability in
            DispatchQueue.main.async() {
                completionHandler(false,"Failed")
            }
        }
        do {
            try reachability?.startNotifier()
        } catch {
            print("Unable to start notifier")
        }
    }

}
