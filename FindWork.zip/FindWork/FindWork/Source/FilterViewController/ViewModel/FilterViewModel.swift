//----------------------------------------------------------------------
/*
 Name - FilterViewModel.swift
 Description:
 1.
 Created by divya_ios on 22/08/18.
 Last updated on - 22/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

class FilterViewModel : NSObject {
    
    var filterCategory = [FilterCategory]() //Struct contain both category and subcategory
    
    override init() {
        super.init()
        self.loadDummyData() //Dummy data loading
    }
    
    
    func loadDummyData(){
        for i in 0...5{
            let filterSubCategory = FilterSubCategory(title: "Title\(i)")
            filterCategory.append(FilterCategory(title: "Category1", filterSubCategory: [filterSubCategory,filterSubCategory,filterSubCategory]))
        }
    }
}

extension FilterViewModel : UITableViewDelegate,UITableViewDataSource{
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return filterCategory.count //Cartegory count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterCategory[section].subCategory.count //subcategory count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let filterCell = tableView.dequeueReusableCell(withIdentifier: "FilterCell", for: indexPath) as! FilterTableViewCell
        filterCell.configureFilterCell(data: filterCategory[indexPath.section].subCategory[indexPath.row]) //Populate cell
        return filterCell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let filterCell = tableView.dequeueReusableCell(withIdentifier: "FilterCell") as! FilterTableViewCell
        filterCell.configureFilterHeaderview(data: filterCategory[section])//Populate header view (same filter cell)
        return filterCell.contentView
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        filterCategory[indexPath.section].subCategory[indexPath.row].isSelected = !filterCategory[indexPath.section].subCategory[indexPath.row].isSelected
        tableView.reloadRows(at: [indexPath], with: .none)
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
}
