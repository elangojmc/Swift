//----------------------------------------------------------------------
/*
 Name - FilterModel.swift
 Description:
 1.Created model class for category and subcategory in filter screen
 Created by divya_ios on 22/08/18.
 Last updated on - 22/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

struct FilterCategory { //Main category
    var title = ""
    var subCategory = [FilterSubCategory]()
    
    init(title:String,filterSubCategory:[FilterSubCategory]) {
        self.title = title
        self.subCategory = filterSubCategory
    }
}


struct FilterSubCategory { // Subcategory
    var title : String = ""
    var isSelected = false
  
    init(title:String,isSelected:Bool = false) {
        self.title = title
        self.isSelected = isSelected //Flag to show tick image
    }
}
