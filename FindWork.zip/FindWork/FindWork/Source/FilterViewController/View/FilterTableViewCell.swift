//----------------------------------------------------------------------
/*
 Name - FilterTableViewCell.swift
 Description:
 1.Same cell is used for both header and cell
 Created by divya_ios on 22/08/18.
 Last updated on - 22/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------
import UIKit

class FilterTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgViewTick: UIImageView!
    @IBOutlet weak var seperatorLeading: NSLayoutConstraint!
    @IBOutlet weak var lblCategory: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    func configureFilterCell(data:FilterSubCategory){
        //Populating subcategory
        imgViewTick.isHidden = !data.isSelected //If i selected the cell tick image is shown
        seperatorLeading.constant = 16 //Seperator inset position for cell is 16
        lblCategory.text = data.title
        lblCategory.textColor = !data.isSelected ? UIColor.grayText : UIColor.grayishBrownText //If cell is selected title color is brown color
        self.contentView.backgroundColor = UIColor.clear
    }
    
    func configureFilterHeaderview(data:FilterCategory){
        imgViewTick.isHidden = true
        seperatorLeading.constant = 0 //Seperator inset for header is 0
        lblCategory.textColor = UIColor.seaBlue
        self.contentView.backgroundColor = UIColor.grayShadowOnCell

    }
    
}
