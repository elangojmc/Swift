//----------------------------------------------------------------------
/*
 Name - FilterViewController.swift
 Description:
 1.
 Created by divya_ios on 22/08/18.
 Last updated on - 17/1/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

class FilterViewController: UIViewController {
    
    @IBOutlet weak var filterTableView: UITableView!
    let filterViewModel = FilterViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        filterTableView.register(UINib(nibName: "FilterTableViewCell", bundle: nil), forCellReuseIdentifier: "FilterCell") //Since cell is in xib we have to register the cell to tableview.
        
        //Assign delegate for tableview
        filterTableView.delegate = filterViewModel
        filterTableView.dataSource = filterViewModel
        filterTableView.reloadData()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //--------------------------------------------
    //MARK: - Button Action
    //--------------------------------------------
    
    @IBAction func didClickClose(_ sender: Any) {
        self.dismiss(animated: true, completion: nil) //Close filter view
    }
    
    @IBAction func didClickReset(_ sender: Any) {
        
        for (offset,item) in filterViewModel.filterCategory.enumerated(){
            if let index = item.subCategory.index(where: {$0.isSelected == true}) { //Change all object selected flag to false
                filterViewModel.filterCategory[offset].subCategory[index].isSelected = false
            }
        }
        filterTableView.reloadData()
        
    }
    

}
