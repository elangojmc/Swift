//----------------------------------------------------------------------
/*
 Name - HomeViewModel.swift
 Description:
 1.Delegate for tableview ,Collectionview and search bar
 2.Assigned static data for quick filter view
 Created by divya_ios on 14/08/18.
 Last updated on - 14/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

protocol HomeViewModelDelegate {
    func didClickFilter()
    func didClickQuickFilter()
    func loadMorePagination()
    func showLoader(show: Bool)
    func loadJobList()
}

class HomeViewModel: NSObject {
    
    var quickFilterData = [QuickFilter]()
    var delegate : HomeViewModelDelegate!
    var jobDetails = [JobDetailsData]()
    var pagination : Pagination!
    var selectedFilter = ""
   
    override init() {
        super.init()
        formQuickFilterData()
        
    }
    
    func getJobList(isQuickFilter:Bool,completion:@escaping (ApiStatus)->()){
        let currentPage = self.pagination != nil ? self.pagination.current_page! : 1
        var url = Url.API_JOBS + "?page=\(currentPage)" //If completed job list
        
        if isQuickFilter{
            url =  Url.API_JOBS + "?scope=\(selectedFilter)&country=India&page=\(String(describing: currentPage))&lat=28.644800&lng=77.216721" //Filtered job list
        }

        NetworkManager.apiRequest(urlString: url, Method: .get, parameter: [:],isLoadingNeeded:currentPage == 1 ? true : false) { (status:Result<JobBaseData>) in
            switch status{
            case .success(let data):
                dump(data)
                self.jobDetails.append(contentsOf: data.data!)  // Assign the Jobdetails Array Values
                self.pagination = data.meta?.pagination
                completion(self.jobDetails.count == 0 && self.pagination.current_page == 1 ? .NoData : .Success) //If data count is zero and if we are in first page - Return Nodata (To display nodata view)
                break
            case .failure(let message):
                print(message)
                completion(.NetworkError)
            case .error(let message):
                print(message)
                completion(.NetworkError)
            }
        }
    }


    func formQuickFilterData(){
        quickFilterData.removeAll() //Before loading make that object empty
        
        //set of title and image which is loaded in quick filter
        let quickFilterImage = [#imageLiteral(resourceName: "Recommended"),#imageLiteral(resourceName: "Featured"),#imageLiteral(resourceName: "Trending"),#imageLiteral(resourceName: "Urgent")]
        let quickFilterType = ["Recommended" ,"Featured","Trending","Urgent"]
        for (index, element) in quickFilterType.enumerated() {
            let quickFilterObj = QuickFilter(title: element, image: quickFilterImage[index])
            quickFilterData.append(quickFilterObj) //Formed quick filter data to load
        }
    }
}

extension HomeViewModel : UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jobDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let jobCell = tableView.dequeueReusableCell(withIdentifier: "JobCell", for: indexPath) as! JobCardTableViewCell //Get instance of job card cell by using identifier
        jobCell.configureJobCardCell(jobDetails[indexPath.row]) // Populate the data in JobCardCell
        if selectedFilter == "Featured" {
            jobCell.showFeatureView() //If it is Featured - Should show feature view in job list
        } else {
            jobCell.hideFeatureView()
        }
        return jobCell
    }
}

extension HomeViewModel : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return quickFilterData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let filterCardcell = collectionView.dequeueReusableCell(withReuseIdentifier: "FilterCardCell", for: indexPath) as! QuickFilterCardCollectionViewCell//Get instance of Quick filter card cell by using identifier
        filterCardcell.configureQuickFilterView(quickFilter: quickFilterData[indexPath.row]) //Populate data in filter cell
        return filterCardcell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //Width is multiple 1.7 of height of cell
        return CGSize(width: (collectionView.frame.size.height * 1.7), height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.pagination.current_page = 1
        selectedFilter = quickFilterData[indexPath.row].title
        if let index = self.quickFilterData.index(where: {$0.isSelected == true}) { //Change all object selected flag to false
            if(index != indexPath.row){ //This is done to untick the selected filter
                self.quickFilterData[index].isSelected = false
                print("UnTick")
                self.jobDetails.removeAll() // removing all details before appending data
                self.delegate.didClickQuickFilter() //To reload job deta

            }else{
                self.quickFilterData[index].isSelected = false
                collectionView.reloadData()//Reload particular index
                self.jobDetails.removeAll()
                self.delegate.loadJobList()// load data without quckfilter
                return
            }
        }
        quickFilterData[indexPath.row].isSelected = !quickFilterData[indexPath.row].isSelected //Use this flag to show or hide tick button
        collectionView.reloadData()//Reload particular index
        self.jobDetails.removeAll() //
        self.delegate.didClickQuickFilter() //To reload job deta
    }
    
}

extension HomeViewModel : UISearchBarDelegate{
    func searchBarBookmarkButtonClicked(_ searchBar: UISearchBar) {
        //If filter button is clicked
        if searchBar.image(for: .bookmark, state: .normal) == #imageLiteral(resourceName: "Filter"){
            self.delegate.didClickFilter()
        }
        searchBar.setShowsCancelButton(false, animated: true) //Hide cancel button
        searchBar.setImage(#imageLiteral(resourceName: "Filter"), for: .bookmark, state: UIControlState.normal)
        searchBar.text = ""
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        //Did click Go in keyboard
        if(searchBar.text != ""){
            searchBar.setShowsCancelButton(true, animated: true) //Show cancel button
            searchBar.setImage(#imageLiteral(resourceName: "ClearTextIcon"), for: .bookmark, state: UIControlState.normal)
            searchBar.endEditing(true)//Dismiss keyboard
            if let cancelButton = searchBar.value(forKey: "cancelButton") as? UIButton{
                cancelButton.isEnabled = true
            }
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true) //Hide cancel button
        searchBar.setImage(#imageLiteral(resourceName: "Filter"), for: .bookmark, state: UIControlState.normal)
        searchBar.text = ""
        searchBar.endEditing(true)//Dismiss keyboard
    }
}

extension HomeViewModel : UIScrollViewDelegate {

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height //getting scrollview total frame height
        let contentYoffset = scrollView.contentOffset.y //getting scroll view contentsize in y orgin
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom <= height {
            print("table end")
            if let currentpage = self.pagination.current_page , let totalPage = self.pagination.total_pages{
                if currentpage < totalPage{ // change page number only when current page less than total page
                    self.pagination.current_page = 1 + self.pagination.current_page! // increasing the current page  by one
                    self.delegate.loadMorePagination()
                    self.delegate.showLoader(show: true) 
                }else{
                    self.delegate.showLoader(show: false)
                }
            }
        }
    }
    
}
