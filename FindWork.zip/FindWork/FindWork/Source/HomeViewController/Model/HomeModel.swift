//----------------------------------------------------------------------
/*
 Name - HomeModel.swift
 Description:
 1.
 Created by divya_ios on 17/08/18.
 Last updated on - 17/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

//Quick filter tap action handling struct
struct QuickFilter{
    var title : String!
    var image : UIImage!
    var isSelected : Bool!
    
    init(title:String,image:UIImage) {
        self.title = title
        self.image = image
        self.isSelected = false //This is for select and unselect the filter option
    }
}

//Created Base class for Job list Api


struct Details : Codable { //Job details
    
    let data : [String]?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        data = try values.decodeIfPresent([String].self, forKey: .data) ?? [""]
    }
}

struct JobBaseData : Codable {
    let data : [JobDetailsData]?
    let meta : Meta?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        data = try values.decodeIfPresent([JobDetailsData].self, forKey: .data)
        meta = try values.decodeIfPresent(Meta.self, forKey: .meta)
    }
    
}

struct JobDetailsData : Codable { //Job data
    
    let id : String?
    let code : String?
    let cover : String?
    let title : String?
    let description : String?
    let requirements : String?
    let category : Category?
    let type : String?
    let company : Company?
    let location : Location?
    let salary : Salary?
    let schedule : [String]?
    let slug : String?
    let posted : String?
    let status : Int?
    let details : Details?
    let distance : Double?
    let featured : Bool?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(String.self, forKey: .id) ?? " "
        code = try values.decodeIfPresent(String.self, forKey: .code) ?? " "
        cover = try values.decodeIfPresent(String.self, forKey: .cover) ?? " "
        title = try values.decodeIfPresent(String.self, forKey: .title) ?? " "
        description = try values.decodeIfPresent(String.self, forKey: .description) ?? " "
        requirements = try values.decodeIfPresent(String.self, forKey: .requirements) ?? " "
        category = try values.decodeIfPresent(Category.self, forKey: .category)
        type = try values.decodeIfPresent(String.self, forKey: .type) ?? " "
        company = try values.decodeIfPresent(Company.self, forKey: .company)
        location = try values.decodeIfPresent(Location.self, forKey: .location)
        salary = try values.decodeIfPresent(Salary.self, forKey: .salary)
        schedule = try values.decodeIfPresent([String].self, forKey: .schedule)
        slug = try values.decodeIfPresent(String.self, forKey: .slug) ?? " "
        posted = try values.decodeIfPresent(String.self, forKey: .posted) ?? " "
        status = try values.decodeIfPresent(Int.self, forKey: .status) ?? 0
        details = try values.decodeIfPresent(Details.self, forKey: .details)
        distance = try values.decodeIfPresent(Double.self, forKey: .distance) ?? 0
        featured = try values.decodeIfPresent(Bool.self, forKey: .featured) ?? false
    }
}
struct Category : Codable { //Job Categories
    let id : Int?
    let name : String?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id) ?? 0
        name = try values.decodeIfPresent(String.self, forKey: .name) ?? " "
    }
}

struct Company : Codable { //Job company details
    
    let name : String?
    let email : String?
    let logo : String?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decodeIfPresent(String.self, forKey: .name) ?? " "
        email = try values.decodeIfPresent(String.self, forKey: .email) ?? " "
        logo = try values.decodeIfPresent(String.self, forKey: .logo) ?? " "
    }
    
}

struct Location : Codable { //Job location
    let address : String?
    let city : String?
    let zip : String?
    let state : String?
    let country : String?
    let latitude : String?
    let longitude : String?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        address = try values.decodeIfPresent(String.self, forKey: .address) ?? " "
        city = try values.decodeIfPresent(String.self, forKey: .city) ?? " "
        zip = try values.decodeIfPresent(String.self, forKey: .zip) ?? " "
        state = try values.decodeIfPresent(String.self, forKey: .state) ?? " "
        country = try values.decodeIfPresent(String.self, forKey: .country) ?? " "
        latitude = try values.decodeIfPresent(String.self, forKey: .latitude) ?? " "
        longitude = try values.decodeIfPresent(String.self, forKey: .longitude) ?? " "
    }
}

struct Salary : Codable { //Job salary
    let currency : String?
    let min : Int?
    let max : Int?
    let type : String?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        currency = try values.decodeIfPresent(String.self, forKey: .currency) ?? " "
        min = try values.decodeIfPresent(Int.self, forKey: .min) ?? 0
        max = try values.decodeIfPresent(Int.self, forKey: .max) ?? 0
        type = try values.decodeIfPresent(String.self, forKey: .type) ?? ""
    }
}


struct Meta : Codable { //Pagination base class
    let pagination : Pagination?
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        pagination = try values.decodeIfPresent(Pagination.self, forKey: .pagination)
    }
    
}

struct Pagination : Codable { //Pagination class
    let total : Int?
    let count : Int?
    let per_page : Int?
    var current_page : Int?
    let total_pages : Int?
//    let links : Links? //
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        total = try values.decodeIfPresent(Int.self, forKey: .total) ?? 0
        count = try values.decodeIfPresent(Int.self, forKey: .count) ?? 0
        per_page = try values.decodeIfPresent(Int.self, forKey: .per_page) ?? 0
        current_page = try values.decodeIfPresent(Int.self, forKey: .current_page) ?? 0
        total_pages = try values.decodeIfPresent(Int.self, forKey: .total_pages) ?? 0
//        links = try values.decodeIfPresent(Links.self, forKey: .links) ??
    }
    
}

//struct Links : Codable {
//    let next : String?
//
//    init(from decoder: Decoder) throws {
//        let values = try decoder.container(keyedBy: CodingKeys.self)
//        next = try values.decodeIfPresent(String.self, forKey: .next) ?? ""
//    }
//
//}
