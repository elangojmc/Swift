//----------------------------------------------------------------------
/*
 Name - HomeViewController.swift
 Description:
 1.The first tab screen which display the jobs list
 2.Filter option is there. - Move to seperate screen
 3.Search option is there in the same screen
 Created by divya_ios on 14/08/18.
 Last updated on - 14/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------


import UIKit

class HomeViewController: UIViewController {
   
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var filterCardCollectionView: UICollectionView!
    @IBOutlet weak var jobTableView: UITableView!
    
    
    let homeViewModel = HomeViewModel()
    var resfreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        //Setup view before loading the view
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //--------------------------------------------
    //MARK: - Function
    //--------------------------------------------
    
    func setupView(){
        
        jobTableView.register(UINib(nibName: "JobCardTableViewCell", bundle: nil), forCellReuseIdentifier: "JobCell") //Since cell is in xib we have to register the cell to tableview.
        
        filterCardCollectionView.register(UINib(nibName: "QuickFilterCardCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "FilterCardCell") // Register the collection view cell.
        homeViewModel.delegate = self
        searchBar.delegate = homeViewModel
        
        jobTableView.delegate = homeViewModel
        jobTableView.dataSource = homeViewModel
        filterCardCollectionView.delegate = homeViewModel
        filterCardCollectionView.dataSource = homeViewModel
        loadJobList(isQuickfilter: false) //If false all job list
        
        
    }
    
    func loadJobList(isQuickfilter:Bool){
        homeViewModel.getJobList(isQuickFilter: isQuickfilter) { (status) in
            if(status == .Success){
                self.jobTableView.reloadData()
            }else if(status == .NoData){
                self.jobTableView.reloadData() // There is No data from response
            }else if(status == .NetworkError){
                self.jobTableView.reloadData()//Display wifi not connected view
            }
        }
    }
    
    func addRefreshControl() {
        resfreshControl.attributedTitle = NSAttributedString.init(string: "Load More")
        resfreshControl.beginRefreshing()
        jobTableView.addSubview(resfreshControl)
    }
    
    func footerView() -> UIView
    {
    let view = UIView(frame:CGRect(x: 0, y: 0, width: self.view.frame.width, height: 50))
    let label  = UILabel(frame:CGRect(x:  self.view.frame.width/2 - 20 , y: 0, width: 80, height: 40))
    let loader = UIActivityIndicatorView(frame:CGRect(x: self.view.frame.width/2 - 60, y: 5, width: 35, height: 35))
    label.text = "Loading...."
    label.font = UIFont(name: "Lato-Light", size: 14)
//    label.textColor = UIColor.appCyan
    view.addSubview(label)
    loader.tintColor = UIColor.darkGray
    view.addSubview(loader)
    loader.startAnimating()
    return view
    }
  
    
    //--------------------------------------------
    //MARK: - Button Action
    //--------------------------------------------

}

extension HomeViewController : HomeViewModelDelegate{
    func didClickQuickFilter(){
         loadJobList(isQuickfilter: true) //If true filter the job list
    }
    func loadMorePagination(){
       let count = homeViewModel.quickFilterData.filter{$0.isSelected}.count
        loadJobList(isQuickfilter: count > 0 ? true : false) //Call pagination API,If true filter the job list
//        addRefreshControl() // Add Refresh COntrol in Tableview
    }
    func didClickFilter(){
        let filterVc = self.storyboard?.instantiateViewController(withIdentifier: "FilterViewController") as! FilterViewController
        self.present(filterVc, animated: true, completion: nil)
    }
    func showLoader(show: Bool){
        
        if show{
            self.jobTableView.tableFooterView = self.footerView()
        }else{
           self.jobTableView.tableFooterView = UIView.init()
        }
    }
    func loadJobList(){
        loadJobList(isQuickfilter: false)
    }

}
