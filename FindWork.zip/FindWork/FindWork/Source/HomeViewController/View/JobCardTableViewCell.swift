//----------------------------------------------------------------------
/*
 Name - JobCardTableViewCell.swift
 Description:
 1.Card reused in following screen
   ->Home (Recommended and new) - MainTabView
   ->My Jobs - MainTabView
 Created by divya_ios on 14/08/18.
 Last updated on - 14/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit
import SDWebImage

class JobCardTableViewCell: UITableViewCell {
    
    //These three outlet to hide the feature view for other filters
    @IBOutlet weak var lblFeature: UILabel!
    @IBOutlet weak var imgViewStar: UIImageView!
    @IBOutlet weak var featureViewHeight: NSLayoutConstraint!
    @IBOutlet weak var shadowView: UIView!
    
    @IBOutlet weak var imgCover: UIImageView!
    @IBOutlet weak var imgCompanyLogo : UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblSalary: UILabel!
    @IBOutlet weak var lblJobType: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblCompanyname: UILabel!
    @IBOutlet weak var lblPostedStatus: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        hideFeatureView()
        shadowView.layer.applySketchShadow(color: UIColor.grayShadow) //Give shadow effect to the sub view of content view.
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func configureJobCardCell(_ jobDetails:JobDetailsData) -> Void {
        // Populate the Data In Particular Label Form JobDetailsData
        
        lblTitle.text = jobDetails.title!
        if let location = jobDetails.location {
            lblLocation.text = location.city! + "," + location.country! + "\(jobDetails.distance!)"
        }
        if let salary = jobDetails.salary {
            lblSalary.text = salary.currency! + " " + "\(salary.min!)" + "-" + "\(salary.max!)"
            lblJobType.text = salary.type
        }
        lblDescription.text = jobDetails.description
        if let company = jobDetails.company {
            lblCompanyname.text = company.name
            imgCompanyLogo.sd_setImage(with: URL(string: company.logo!), placeholderImage: #imageLiteral(resourceName: "CompanyLoaderSmall"))
        }
        lblPostedStatus.text = jobDetails.posted

        imgCover.sd_setImage(with: URL(string: jobDetails.cover!), placeholderImage: #imageLiteral(resourceName: "CompanyLoaderLarge"))
       
    }
    func hideFeatureView(){
        //Hide feature button - If featured quick filter is not selected
        lblFeature.isHidden = true
        imgViewStar.isHidden = true
        self.featureViewHeight.constant = 0
    }
    
    func showFeatureView(){
        //Show feature button - If featured quick filter is selected
        lblFeature.isHidden = false
        imgViewStar.isHidden = false
        self.featureViewHeight.constant = 30
    }
    
}
