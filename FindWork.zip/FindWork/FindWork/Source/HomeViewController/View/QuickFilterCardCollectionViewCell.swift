//----------------------------------------------------------------------
/*
 Name - QuickFilterCardCollectionViewCell.swift
 Description:
 1.
 Created by divya_ios on 17/08/18.
 Last updated on - 17/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

class QuickFilterCardCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var btnTick: UIButton!
    @IBOutlet weak var lblFilterType: UILabel!
    @IBOutlet weak var imgViewFilter: UIImageView!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.applySketchShadow(color: UIColor.grayShadow) //Give shadow effect to the sub view of content view.
        gradientView.layer.setGradientEffect(colorTop: UIColor.clear, colorBottom: UIColor.black) //Added gradient effect to the view behind image
        // Initialization code
    }
    
    func configureQuickFilterView(quickFilter:QuickFilter){ //Populate quick filter view
        self.lblFilterType.text = quickFilter.title
        self.imgViewFilter.image = quickFilter.image
        self.btnTick.isHidden = !quickFilter.isSelected
    }

}
