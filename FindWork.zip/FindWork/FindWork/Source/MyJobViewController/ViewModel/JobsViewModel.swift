//----------------------------------------------------------------------
/*
 Name - JobsViewModel.swift
 Description:
 1.
 Created by divya_ios on 8/23/18.
 Last updated on - 8/23/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------


import UIKit

class JobsViewModel: NSObject {
    
    var jobStatusType = ["New","NotSuitable","ShortListed","Interview","Hired"] // Dummy Data
    var segmentIndex = Int() //Current selected index
}


extension JobsViewModel : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return jobStatusType.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyJobsCell",for:indexPath) as! MyJobsTableViewCell
        //segment 0 - Applied, Segment 1 - Saved
        if segmentIndex == 0 {
            cell.configureAppliedJob(jobStatusType[indexPath.row]) //Populate applied job
        } else {
            cell.configureSavedJob() // Populate saved job
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let cell = tableView.cellForRow(at: indexPath) as? MyJobsTableViewCell
        let status = AppliedJobStatus(rawValue: (cell?.lblStatus.text)!)//Get status
        
        let deleteAction  = UITableViewRowAction(style: .default, title: "       ") { (action, indexPath) in
            //Delete action should be here.
        }
        
        //Base view for swipe
        let view = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 100, height: (cell?.frame.height)!))
        view.backgroundColor = AppliedJobStatus(rawValue: status!.rawValue)?.swipebackgroundColor
        
        // Add Image
        let imageView = UIImageView.init(frame: CGRect.init(x: (100 - 50)/2, y: (view.frame.height - 50)/2, width: 28, height: 28))
        imageView.image = AppliedJobStatus(rawValue: status!.rawValue)?.swipeImage
        view.addSubview(imageView)
        
        //Add Label
        let label = UILabel.init(frame: CGRect.init(x: -5, y:imageView.frame.origin.y + imageView.frame.size.height + 5 , width: view.frame.width - 5, height: 25))
        label.text = AppliedJobStatus(rawValue: status!.rawValue)?.swipeTitle
        label.textAlignment = .center
        label.font = UIFont.init(name: "SFUIText-Regular", size: 14)
        label.textColor = AppliedJobStatus(rawValue: status!.rawValue)?.swipeTitleColor
        view.addSubview(label)
        
        let imgSize : CGSize = tableView.frame.size
        UIGraphicsBeginImageContextWithOptions(imgSize, false, UIScreen.main.scale)
        let context = UIGraphicsGetCurrentContext()
        view.layer.render(in: context!)
        let newImage : UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        deleteAction.backgroundColor = UIColor.init(patternImage: newImage)
        return [deleteAction]
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        //Swipe action should work only for not suitable and new status
        if let cell = tableView.cellForRow(at: indexPath) as? MyJobsTableViewCell{
            let status = AppliedJobStatus(rawValue: (cell.lblStatus.text)!)
            if(status!.rawValue == AppliedJobStatus.Notsuitable.rawValue || status!.rawValue == AppliedJobStatus.New.rawValue){
                return true //If true swipe will occure
            }
        }
        return false //If false swipe will not occur
        
    }
    
    
}
