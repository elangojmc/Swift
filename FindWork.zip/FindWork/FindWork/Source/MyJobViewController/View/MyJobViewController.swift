//----------------------------------------------------------------------
/*
 Name - MyJobViewController.swift
 Description:
 1.Populae the MyJobs Status Details
 Created by divya_ios on 22/08/18.
 Last updated on - 22/08/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

class MyJobViewController: UIViewController {
    
    @IBOutlet weak var jobsTableview: UITableView!
    @IBOutlet weak var segmentControl: UISegmentedControl!

    let jobsviewModel = JobsViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setUpConfiguration()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //--------------------------------------------
    //MARK: - Function
    //--------------------------------------------
    
    func setUpConfiguration()  {
        self.segmentControl.subviews[1].accessibilityLabel = "Saved"
        self.segmentControl.subviews[0].accessibilityLabel = "Applied"


        // The Cell is in XIB .We need to assign the Cell to tableview
        let cellNib = UINib.init(nibName: "MyJobsTableViewCell", bundle: nil)
        jobsTableview.register(cellNib, forCellReuseIdentifier: "MyJobsCell")
        
        //Assign the tableview Delegate and Datasource Methods
        jobsTableview.delegate = jobsviewModel
        jobsTableview.dataSource = jobsviewModel
        jobsTableview.reloadData()
        
        // SetUp the segmentControl
        setUptheSegementControl()
    }
    
    func setUptheSegementControl()  {
        //Set SegmentControl Text Font Style
        let font: [AnyHashable : Any] = [NSAttributedStringKey.font :UIFont(name: "SanFranciscoText-Regular", size: 14.0)!]
        segmentControl.setTitleTextAttributes(font, for: .normal)

    }
    
    //--------------------------------------------
    //MARK: - Button Action
    //--------------------------------------------
    @IBAction func actionSegmentControl(_ sender: UISegmentedControl){
        
        jobsviewModel.segmentIndex = sender.selectedSegmentIndex // Assign the selected Segmented Index to viewmodel Instance
        jobsTableview.reloadData()
    }
}
