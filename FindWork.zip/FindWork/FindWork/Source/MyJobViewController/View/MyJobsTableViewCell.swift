//----------------------------------------------------------------------
/*
 Name - MyJobsTableViewCell.swift
 Description:
 1.Populate the applied and saved job
 2.Since same xib file is used for both type We differentiated using segment index
  Created by divya_ios on 8/22/18.
 Last updated on - 8/22/18
 Last updated by - divya_ios.
 */
//----------------------------------------------------------------------

import UIKit

class MyJobsTableViewCell: UITableViewCell {

    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var imgViewHighlight: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func configureAppliedJob(_ jobStatus:String) -> Void {//Populate applied job status
        lblStatus.text = jobStatus
        lblStatus.textColor = (AppliedJobStatus(rawValue: jobStatus)?.color)!
        lblStatus.bordercolor = (AppliedJobStatus(rawValue: jobStatus)?.color)!
        lblStatus.isHidden = false // Job status label is required in applied
        imgViewHighlight.image = #imageLiteral(resourceName: "CheckBox")
    }
    
    func configureSavedJob() -> Void {//Populate saved job status
        lblStatus.isHidden = true // Job status label is not required in Saved Status
        imgViewHighlight.image = #imageLiteral(resourceName: "SaveJob")
        
    }

}

