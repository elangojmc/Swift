//
//  ViewController.swift
//  DemoCodable
//
//  Created by Ratheesh TR on 9/18/18.
//  Copyright © 2018 Ratheesh TR. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let url = URL(string: "http://temp1.pickzy.com/interview_pickzy/interview.json") else {
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            
            guard let data = data else {return}
            
            do {
                let decoder = JSONDecoder()
                let pickzyImages = try decoder.decode(PickZyImages.self, from: data)
                print(pickzyImages)
                
                
//                let encoder = JSONEncoder()
//                let pickzyImagesEncodedData = try encoder.encode(pickzyImages)
//                print(pickzyImagesEncodedData)
//
                self.saveImages(data)
                self.fetchImages()
                
//                let decoder1 = JSONDecoder()
//                let pickzyImages1 = try decoder1.decode(PickZyImages.self, from: pickzyImagesEncodedData)
//                print(pickzyImages1)

            }
            catch let err {
                print(err.localizedDescription)
            }
            
        }.resume()
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func saveImages(_ imagesData: Data) {
       
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "User", in: managedObjectContext)
        
        let user = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
        
        user.setValue(imagesData, forKey: "name")
        
        do {
            try managedObjectContext.save()
        } catch let err {
            print(err.localizedDescription)
        }
        
    }
    
    func fetchImages() {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        
        do {
            let result = try managedObjectContext.fetch(request) as! [NSManagedObject]
            let firstObj = result.last
            let data = firstObj?.value(forKey: "name")
            
            let decoder = JSONDecoder()
            let pickzyImages = try decoder.decode(PickZyImages.self, from: data as! Data)
            print(pickzyImages)
            
        } catch let err {
            print(err.localizedDescription)
        }
        
    }
    
    
}

