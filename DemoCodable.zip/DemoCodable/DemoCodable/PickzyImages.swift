//
//  PickzyImages.swift
//  DemoCodable
//
//  Created by Ratheesh TR on 9/18/18.
//  Copyright © 2018 Ratheesh TR. All rights reserved.
//



import Foundation

struct PickZyImages: Codable {
    let item:Item
    
    enum CodingKeys: CodingKey, String {
        case item = "Item"
    }
}

struct Item: Codable {
    let content : [Content]
    enum CodingKeys: CodingKey, String {
        case content = "Content"
    }
}

struct Content: Codable {
    let name: String?
    let url: URL?
    
    enum CodingKeys: CodingKey, String {
        case name = "Name"
        case url = "URL"
    }
}

